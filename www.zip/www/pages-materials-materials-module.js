(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["pages-materials-materials-module"],{

/***/ "./src/app/pages/materials/materials.module.ts":
/*!*****************************************************!*\
  !*** ./src/app/pages/materials/materials.module.ts ***!
  \*****************************************************/
/*! exports provided: MaterialsPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MaterialsPageModule", function() { return MaterialsPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _materials_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./materials.page */ "./src/app/pages/materials/materials.page.ts");







var routes = [
    {
        path: '',
        component: _materials_page__WEBPACK_IMPORTED_MODULE_6__["MaterialsPage"]
    }
];
var MaterialsPageModule = /** @class */ (function () {
    function MaterialsPageModule() {
    }
    MaterialsPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterModule"].forChild(routes)
            ],
            declarations: [_materials_page__WEBPACK_IMPORTED_MODULE_6__["MaterialsPage"]]
        })
    ], MaterialsPageModule);
    return MaterialsPageModule;
}());



/***/ }),

/***/ "./src/app/pages/materials/materials.page.html":
/*!*****************************************************!*\
  !*** ./src/app/pages/materials/materials.page.html ***!
  \*****************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header>\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <ion-back-button defaultHref=\"/home\"></ion-back-button> \n    </ion-buttons>\n    <ion-title style=\"font-weight: 400;\">Materials</ion-title>\n    <!-- <ion-buttons slot=\"end\">\n      <ion-button>\n        <ion-icon name=\"search\"></ion-icon>\n      </ion-button>\n      <ion-button>\n        <ion-icon name=\"more\"></ion-icon>\n      </ion-button>\n    </ion-buttons> -->\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>    \n  <!-- <ion-item lines=\"none\">\n    <ion-icon name=\"document\" slot=\"start\"></ion-icon>\n    <ion-label>\n      <ion-text><h2>Camsur Techno Fair.pdf</h2></ion-text>\n        <small style=\"color: #999\">123 kb</small>  \n    </ion-label> \n    \n  </ion-item>    -->\n  <!--<ion-list color=\"light\">\n    <ion-item *ngIf=\"material\" lines=\"none\">\n      <ion-thumbnail slot=\"start\">\n        <ion-img src=\"{{ material.url }}\"></ion-img>\n      </ion-thumbnail>\n      <ion-label>\n        <p> {{ material.fileName }} </p>\n        <ion-text color=\"medium\">\n          <small> {{ material.size }} kb </small>\n        </ion-text>\n      </ion-label>\n      <ion-button (click)=\"onDownloadFile(material)\" fill=\"clear\" slot=\"end\">\n        <ion-ripple-effect></ion-ripple-effect>\n        <ion-icon color=\"primary\" name=\"cloud-download\" size=\"large\"></ion-icon>\n      </ion-button>\n    </ion-item>\n  </ion-list>-->\n      <ion-list *ngIf=\"events\" color=\"light\" no-padding>  \n        <ion-item lines=\"full\">\n          <ion-label>\n            <p style=\"color: black; font-size: 16px; font-weight: 350;\">{{ events.length }} events found</p>\n            <p style=\"font-size: 12px; font-weight: 300;\">Select an event to upload materials</p>\n          </ion-label>\n        </ion-item> \n        <ion-item class=\"item\" lines=\"full\" *ngFor=\"let event of events\" (click)=\"navigateToEventMaterialsPage(event)\" button>\n          <ion-ripple-effect type=\"bounded\"></ion-ripple-effect>\n          <ion-thumbnail slot=\"start\">\n            <ion-img src=\"{{ baseUrl + event.event_image_path }}\"></ion-img>\n          </ion-thumbnail>\n          <ion-label>\n            <p style=\"color: black; font-size: 16px; font-weight: 350;\"> \n              {{ event.event_title }}\n            </p>\n            <p style=\"font-size: 12px; font-weight: 300;\" [innerHTML]=\"event.event_description\"> \n              {{ event.event_description }}\n            </p>  \n          </ion-label>  \n          <ion-icon slot=\"end\" name=\"arrow-forward\" mode=\"ios\" size=\"small\"></ion-icon> \n        </ion-item> \n      </ion-list>\n\n      <ion-list *ngIf=\"!events\" color=\"light\" no-padding>  \n        <ion-item lines=\"full\">\n          <ion-label>\n            <p><ion-skeleton-text animated style=\"width: 35%\"></ion-skeleton-text></p>\n            <p><ion-skeleton-text animated style=\"width: 55%\"></ion-skeleton-text></p>\n          </ion-label>\n        </ion-item> \n        <ion-item class=\"item\" lines=\"none\" *ngFor=\"let skeletonItem of skeletonItems\">\n          <ion-thumbnail slot=\"start\">\n            <ion-skeleton-text animated style=\"width: 100%\"></ion-skeleton-text>\n          </ion-thumbnail>\n          <ion-label>\n            <p style=\"color: black; font-size: 16px; font-weight: 350;\"> \n               <ion-skeleton-text animated style=\"width: 82.5%\"></ion-skeleton-text>\n            </p>\n            <p style=\"font-size: 12px; font-weight: 300;\"> \n              <ion-skeleton-text animated style=\"width: 25%\"></ion-skeleton-text>\n            </p>  \n          </ion-label>   \n        </ion-item> \n      </ion-list>\n\n\n        <!-- <ion-item lines=\"none\">\n          <ion-icon name=\"document\" slot=\"start\"></ion-icon>\n          <ion-label>\n            <h3 style=\"color: #555\"><b>Camsur Techno Fair.pdf</b></h3> \n            <small style=\"color: #999\">123 kb</small>  \n          </ion-label> \n        </ion-item>  \n        <ion-item lines=\"none\">\n          <ion-icon name=\"play-circle\" slot=\"start\"></ion-icon>\n          <ion-label>\n            <h3 style=\"color: #555\"><b>Techno Fair Presentation.mp4</b></h3> \n            <small style=\"color: #999\">49.1 mb</small>         \n          </ion-label> \n        </ion-item> \n        <ion-item lines=\"none\">\n          <ion-icon name=\"image\" slot=\"start\"></ion-icon>\n          <ion-label>\n            <h3 style=\"color: #555\"><b>Flowchart.png</b></h3> \n            <small style=\"color: #999\">12 kb</small>    \n          </ion-label> \n        </ion-item>     -->  \n\n      <!-- <ion-fab vertical=\"bottom\" horizontal=\"end\" slot=\"fixed\" padding-bottom padding-end>\n        <ion-fab-button color=\"light\" (click)=\"onChooseFile()\"> \n          <ion-icon color=\"primary\" name=\"add\" large></ion-icon>\n        </ion-fab-button>\n        <ion-fab-button color=\"medium\" (click)=\"onDownloadFile()\">\n          <ion-icon name=\"star\"></ion-icon>\n        </ion-fab-button> -->\n      <!-- </ion-fab>  -->\n</ion-content>\n"

/***/ }),

/***/ "./src/app/pages/materials/materials.page.scss":
/*!*****************************************************!*\
  !*** ./src/app/pages/materials/materials.page.scss ***!
  \*****************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "ion-item .events-found-item {\n  background-color: black !important; }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcGFnZXMvbWF0ZXJpYWxzL0Q6XFxXb3Jrc3BhY2VcXGlvbmljXFx0aXJpcG9uLXNwZWFrZXItYXBwL3NyY1xcYXBwXFxwYWdlc1xcbWF0ZXJpYWxzXFxtYXRlcmlhbHMucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0ksa0NBQWtDLEVBQUEiLCJmaWxlIjoic3JjL2FwcC9wYWdlcy9tYXRlcmlhbHMvbWF0ZXJpYWxzLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbImlvbi1pdGVtIC5ldmVudHMtZm91bmQtaXRlbSB7XHJcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiBibGFjayAhaW1wb3J0YW50O1xyXG59Il19 */"

/***/ }),

/***/ "./src/app/pages/materials/materials.page.ts":
/*!***************************************************!*\
  !*** ./src/app/pages/materials/materials.page.ts ***!
  \***************************************************/
/*! exports provided: MaterialsPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MaterialsPage", function() { return MaterialsPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _ionic_native_file_ngx__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic-native/file/ngx */ "./node_modules/@ionic-native/file/ngx/index.js");
/* harmony import */ var _ionic_native_file_chooser_ngx__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic-native/file-chooser/ngx */ "./node_modules/@ionic-native/file-chooser/ngx/index.js");
/* harmony import */ var _ionic_native_file_opener_ngx__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic-native/file-opener/ngx */ "./node_modules/@ionic-native/file-opener/ngx/index.js");
/* harmony import */ var _ionic_native_file_path_ngx__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic-native/file-path/ngx */ "./node_modules/@ionic-native/file-path/ngx/index.js");
/* harmony import */ var _ionic_native_file_transfer_ngx__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic-native/file-transfer/ngx */ "./node_modules/@ionic-native/file-transfer/ngx/index.js");
/* harmony import */ var _services_api_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../services/api.service */ "./src/app/services/api.service.ts");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");









var MaterialsPage = /** @class */ (function () {
    function MaterialsPage(file, fileChooser, filePath, fileOpener, fileTransfer, apiService, actionSheetController, alertController, loadingController, toastController, navController) {
        this.file = file;
        this.fileChooser = fileChooser;
        this.filePath = filePath;
        this.fileOpener = fileOpener;
        this.fileTransfer = fileTransfer;
        this.apiService = apiService;
        this.actionSheetController = actionSheetController;
        this.alertController = alertController;
        this.loadingController = loadingController;
        this.toastController = toastController;
        this.navController = navController;
        this.baseUrl = 'https://www.tiripon.net/assets/event_image/landing/';
        this.skeletonItems = [1, 2, 3, 4, 5, 6, 7, 8];
        this.counter = 3;
    }
    MaterialsPage.prototype.ngOnInit = function () {
        this.getEvents();
    };
    MaterialsPage.prototype.addNewFile = function (file) {
        //alert(JSON.stringify(file)); 
        var url = 'https://www.tiripon.net/assets/dashboard/images/speaker/material/documents/' + file.file_name;
        this.material = {
            databaseId: this.counter,
            fileName: file.client_name,
            size: 594,
            fileExtension: 'pdf',
            url: url
        };
    };
    MaterialsPage.prototype.getEvents = function () {
        var _this = this;
        this.apiService.getEvents().then(function (events) {
            if (_this.hasEvents(events)) {
                //alert(JSON.stringify(events));
                _this.events = events;
            }
            else {
                _this.events = [];
            }
        });
    };
    MaterialsPage.prototype.hasEvents = function (events) {
        var numberOfEvents = events.length;
        if (numberOfEvents >= 1) {
            return true;
        }
        else {
            return false;
        }
    };
    MaterialsPage.prototype.navigateToEventMaterialsPage = function (event) {
        var parameters = {
            queryParams: event
        };
        this.navController.navigateForward(['/event-materials'], parameters);
    };
    MaterialsPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-materials',
            template: __webpack_require__(/*! ./materials.page.html */ "./src/app/pages/materials/materials.page.html"),
            styles: [__webpack_require__(/*! ./materials.page.scss */ "./src/app/pages/materials/materials.page.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_native_file_ngx__WEBPACK_IMPORTED_MODULE_2__["File"],
            _ionic_native_file_chooser_ngx__WEBPACK_IMPORTED_MODULE_3__["FileChooser"],
            _ionic_native_file_path_ngx__WEBPACK_IMPORTED_MODULE_5__["FilePath"],
            _ionic_native_file_opener_ngx__WEBPACK_IMPORTED_MODULE_4__["FileOpener"],
            _ionic_native_file_transfer_ngx__WEBPACK_IMPORTED_MODULE_6__["FileTransfer"],
            _services_api_service__WEBPACK_IMPORTED_MODULE_7__["ApiService"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_8__["ActionSheetController"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_8__["AlertController"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_8__["LoadingController"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_8__["ToastController"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_8__["NavController"]])
    ], MaterialsPage);
    return MaterialsPage;
}());



/***/ })

}]);
//# sourceMappingURL=pages-materials-materials-module.js.map