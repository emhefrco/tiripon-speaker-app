(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["pages-home-home-module"],{

/***/ "./src/app/components/menu/menu.component.html":
/*!*****************************************************!*\
  !*** ./src/app/components/menu/menu.component.html ***!
  \*****************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-menu menuId=\"mainMenu\" side=\"start\">\n  <!-- HEADER -->\n  <ion-header padding-start padding-end>\n    <ion-toolbar>  \n        <ion-item lines=\"none\">\n          <ion-avatar slot=\"start\">\n            <ion-img src=\"assets/images/avatar.png\"></ion-img> \n          </ion-avatar>\n          <ion-label>\n            <p style=\"font-weight: 350; color: black; font-size: 16px;\">Emmanuel S. Hernandez</p>\n            <p style=\"font-weight: 350; font-size: 12px;\">Speaker</p>\n          </ion-label> \n        </ion-item> \n    </ion-toolbar> \n  </ion-header> \n\n  <!-- CONTENT -->\n  <ion-content padding-start padding-end>\n\n    <ion-list lines=\"none\">  \n      \n      <!-- <ion-item detail class=\"menu-button\">\n        <ion-avatar slot=\"start\" class=\"avatar-radius\">\n          <img src=\"/assets/images/profile.png\">\n        </ion-avatar>\n        <p style=\"font-weight: 350; color: black; font-size: 16px;\">Profile</p>\n      </ion-item> -->\n      <ion-item detail class=\"menu-button\" routerLink=\"/events\" (click)=\"closeMenu()\">\n        <ion-ripple-effect type=\"bounded\"></ion-ripple-effect>\n        <ion-avatar slot=\"start\" class=\"avatar-radius\">\n          <img src=\"/assets/images/event.png\">\n        </ion-avatar>\n        <p style=\"font-weight: 350; color: black; font-size: 16px;\">My Events</p>\n      </ion-item>   \n      <ion-item detail class=\"menu-button\" routerLink=\"/materials\" (click)=\"closeMenu()\">\n        <ion-ripple-effect type=\"bounded\"></ion-ripple-effect>\n        <ion-avatar slot=\"start\" class=\"avatar-radius\">\n          <img src=\"/assets/images/folder.png\">\n        </ion-avatar>\n        <ion-label>\n          <p style=\"font-weight: 350; color: black; font-size: 16px;\">Materials</p>\n        </ion-label>\n      </ion-item>\n      <ion-item detail class=\"menu-button\" routerLink=\"/event-chats\" (click)=\"closeMenu()\">\n        <ion-ripple-effect type=\"bounded\"></ion-ripple-effect>\n        <ion-avatar slot=\"start\" class=\"avatar-radius\">\n          <img src=\"/assets/images/chat.png\">\n        </ion-avatar>\n        <p style=\"font-weight: 350; color: black; font-size: 16px;\">Chats</p>\n      </ion-item>\n    </ion-list>\n\n  </ion-content>\n\n  <!-- FOOTER -->\n  <ion-footer>\n    <ion-item lines=\"none\" (click)=\"showConfirmLogout()\">\n      <ion-label text-center>\n          <p style=\"font-weight: 350; color: black; font-size: 16px;\">Logout</p>\n      </ion-label> \n    </ion-item>\n  </ion-footer>\n\n</ion-menu>\n\n<ion-router-outlet main></ion-router-outlet>"

/***/ }),

/***/ "./src/app/components/menu/menu.component.scss":
/*!*****************************************************!*\
  !*** ./src/app/components/menu/menu.component.scss ***!
  \*****************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".email-label {\n  color: #9e9e9e;\n  font-size: 13px; }\n\n.name-label {\n  font-size: 22px; }\n\n.menu-button {\n  --background: rgb(248, 248, 248);\n  --border-radius: 10px;\n  margin-top: 8px; }\n\n.profile-img {\n  margin: auto;\n  width: 5rem;\n  height: 5rem; }\n\nion-header {\n  border: 0px !important;\n  border-bottom-color: transparent !important;\n  background-image: none !important;\n  border-bottom: none !important; }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvY29tcG9uZW50cy9tZW51L0Q6XFxXb3Jrc3BhY2VcXGlvbmljXFx0aXJpcG9uLXNwZWFrZXItYXBwL3NyY1xcYXBwXFxjb21wb25lbnRzXFxtZW51XFxtZW51LmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0ksY0FBYztFQUNkLGVBQWUsRUFBQTs7QUFHbkI7RUFDSSxlQUFlLEVBQUE7O0FBR25CO0VBQ0ksZ0NBQWE7RUFDYixxQkFBZ0I7RUFDaEIsZUFBZSxFQUFBOztBQUduQjtFQUNFLFlBQVk7RUFDWixXQUFXO0VBQ1gsWUFBWSxFQUFBOztBQUdkO0VBQ0ksc0JBQXNCO0VBQ3RCLDJDQUEyQztFQUMzQyxpQ0FBaUM7RUFDakMsOEJBQThCLEVBQUEiLCJmaWxlIjoic3JjL2FwcC9jb21wb25lbnRzL21lbnUvbWVudS5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5lbWFpbC1sYWJlbHtcclxuICAgIGNvbG9yOiAjOWU5ZTllO1xyXG4gICAgZm9udC1zaXplOiAxM3B4O1xyXG59XHJcblxyXG4ubmFtZS1sYWJlbHtcclxuICAgIGZvbnQtc2l6ZTogMjJweDtcclxufVxyXG5cclxuLm1lbnUtYnV0dG9ue1xyXG4gICAgLS1iYWNrZ3JvdW5kOiByZ2IoMjQ4LCAyNDgsIDI0OCk7XHJcbiAgICAtLWJvcmRlci1yYWRpdXM6IDEwcHg7XHJcbiAgICBtYXJnaW4tdG9wOiA4cHg7XHJcbn1cclxuXHJcbi5wcm9maWxlLWltZyB7XHJcbiAgbWFyZ2luOiBhdXRvO1xyXG4gIHdpZHRoOiA1cmVtO1xyXG4gIGhlaWdodDogNXJlbTtcclxufSBcclxuXHJcbmlvbi1oZWFkZXIge1xyXG4gICAgYm9yZGVyOiAwcHggIWltcG9ydGFudDtcclxuICAgIGJvcmRlci1ib3R0b20tY29sb3I6IHRyYW5zcGFyZW50ICFpbXBvcnRhbnQ7XHJcbiAgICBiYWNrZ3JvdW5kLWltYWdlOiBub25lICFpbXBvcnRhbnQ7XHJcbiAgICBib3JkZXItYm90dG9tOiBub25lICFpbXBvcnRhbnQ7XHJcbn0iXX0= */"

/***/ }),

/***/ "./src/app/components/menu/menu.component.ts":
/*!***************************************************!*\
  !*** ./src/app/components/menu/menu.component.ts ***!
  \***************************************************/
/*! exports provided: MenuComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MenuComponent", function() { return MenuComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _ionic_native_facebook_ngx__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic-native/facebook/ngx */ "./node_modules/@ionic-native/facebook/ngx/index.js");
/* harmony import */ var _ionic_storage__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/storage */ "./node_modules/@ionic/storage/fesm5/ionic-storage.js");






var MenuComponent = /** @class */ (function () {
    function MenuComponent(alertController, facebook, menuController, navController, storage) {
        this.alertController = alertController;
        this.facebook = facebook;
        this.menuController = menuController;
        this.navController = navController;
        this.storage = storage;
    }
    MenuComponent.prototype.ngOnInit = function () {
    };
    MenuComponent.prototype.closeMenu = function () {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.menuController.close()];
                    case 1:
                        _a.sent();
                        console.log(1);
                        return [2 /*return*/];
                }
            });
        });
    };
    MenuComponent.prototype.logoutFacebookAccount = function () {
        /*alert(JSON.stringify(this.facebook));
          this.facebook.logout().then(result => {
            alert(JSON.stringify(this.facebook));
            alert(result);
          }, error => {
            alert(error);
          }); */
    };
    MenuComponent.prototype.logout = function () {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.storage.clear()];
                    case 1:
                        _a.sent();
                        return [4 /*yield*/, this.navController.navigateRoot(['/login'], { animated: true })];
                    case 2:
                        _a.sent();
                        return [2 /*return*/];
                }
            });
        });
    };
    MenuComponent.prototype.showConfirmLogout = function () {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var alert;
            var _this = this;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.alertController.create({
                            header: 'Confirm Logout',
                            message: 'Do you want to logout your Tiripon account?',
                            buttons: [
                                {
                                    text: 'Cancel',
                                    role: 'cancel',
                                    cssClass: 'secondary'
                                }, {
                                    text: 'Logout',
                                    cssClass: 'secondary',
                                    handler: function () {
                                        _this.logout();
                                    }
                                }
                            ]
                        })];
                    case 1:
                        alert = _a.sent();
                        return [4 /*yield*/, alert.present()];
                    case 2:
                        _a.sent();
                        return [2 /*return*/];
                }
            });
        });
    };
    MenuComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-menu',
            template: __webpack_require__(/*! ./menu.component.html */ "./src/app/components/menu/menu.component.html"),
            styles: [__webpack_require__(/*! ./menu.component.scss */ "./src/app/components/menu/menu.component.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_2__["AlertController"],
            _ionic_native_facebook_ngx__WEBPACK_IMPORTED_MODULE_3__["Facebook"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["MenuController"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["NavController"],
            _ionic_storage__WEBPACK_IMPORTED_MODULE_4__["Storage"]])
    ], MenuComponent);
    return MenuComponent;
}());



/***/ }),

/***/ "./src/app/pages/home/home.module.ts":
/*!*******************************************!*\
  !*** ./src/app/pages/home/home.module.ts ***!
  \*******************************************/
/*! exports provided: HomePageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "HomePageModule", function() { return HomePageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _home_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./home.page */ "./src/app/pages/home/home.page.ts");
/* harmony import */ var _components_menu_menu_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../components/menu/menu.component */ "./src/app/components/menu/menu.component.ts");








var routes = [
    {
        path: '',
        component: _home_page__WEBPACK_IMPORTED_MODULE_6__["HomePage"]
    }
];
var HomePageModule = /** @class */ (function () {
    function HomePageModule() {
    }
    HomePageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterModule"].forChild(routes)
            ],
            declarations: [_home_page__WEBPACK_IMPORTED_MODULE_6__["HomePage"], _components_menu_menu_component__WEBPACK_IMPORTED_MODULE_7__["MenuComponent"]]
        })
    ], HomePageModule);
    return HomePageModule;
}());



/***/ }),

/***/ "./src/app/pages/home/home.page.html":
/*!*******************************************!*\
  !*** ./src/app/pages/home/home.page.html ***!
  \*******************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<app-menu></app-menu>\n<ion-header>\n  <ion-toolbar>\n    <ion-title style=\"font-weight: 400;\">Home</ion-title>\n    <ion-buttons slot=\"start\">\n      <ion-menu-button slot=\"start\"></ion-menu-button>\n    </ion-buttons>\n  </ion-toolbar>\n</ion-header>\n<ion-content>\n  <ion-item *ngIf=\"events\" lines=\"full\">\n    <ion-label>\n      <p style=\"font-size: 16px; color: black; font-weight: 350;\">Assigned Events <span>(</span>{{ events.length }}<span>)</span></p>  \n    </ion-label> \n  </ion-item> \n    <ion-list *ngIf=\"events\" color=\"light\"> \n      <ion-item class=\"item\" *ngFor=\"let event of events\" (click)=\"navigateToEventPage(event)\" lines=\"none\" button>\n        <ion-ripple-effect type=\"bounded\"></ion-ripple-effect>\n        <ion-thumbnail slot=\"start\">\n          <ion-img src=\"{{ baseUrl + event.event_image_path }}\"></ion-img>\n        </ion-thumbnail>\n        <ion-label>\n          <p style=\"color: black; font-size: 16px; font-weight: 350;\"> \n            {{ event.event_title }}\n          </p>\n          <p style=\"font-size: 12px; font-weight: 300;\"> \n            {{ event.province }}, {{ event.country }} \n          </p> \n          <p style=\"font-size: 12px; font-weight: 300;\">  \n            {{ event.start | date : \"mediumDate\" }} \n          </p> \n        </ion-label> \n      </ion-item>    \n  </ion-list>\n  <ion-item *ngIf=\"!events\" lines=\"full\">\n    <ion-label>\n      <p style=\"font-size: 16px; color: black; font-weight: 350;\"><ion-skeleton-text animated style=\"width: 50%\"></ion-skeleton-text></p>  \n    </ion-label> \n  </ion-item> \n  <ion-list *ngIf=\"!events\" color=\"light\"> \n    <ion-item class=\"item\" lines=\"none\" *ngFor=\"let skeletonItem of skeletonItems\">\n      <ion-thumbnail slot=\"start\">\n        <ion-skeleton-text animated style=\"width: 100%\"></ion-skeleton-text>\n      </ion-thumbnail>\n      <ion-label>\n        <p style=\"color: black; font-size: 16px; font-weight: 350;\"> \n          <ion-skeleton-text animated style=\"width: 100%\"></ion-skeleton-text>\n        </p>\n        <p style=\"font-size: 12px; font-weight: 300;\"> \n          <ion-skeleton-text animated style=\"width: 75%\"></ion-skeleton-text>\n        </p> \n        <p style=\"font-size: 12px; font-weight: 300;\">  \n          <ion-skeleton-text animated style=\"width: 50%\"></ion-skeleton-text>\n        </p> \n      </ion-label> \n    </ion-item>    \n  </ion-list>\n</ion-content>"

/***/ }),

/***/ "./src/app/pages/home/home.page.scss":
/*!*******************************************!*\
  !*** ./src/app/pages/home/home.page.scss ***!
  \*******************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".item ion-thumbnail {\n  min-width: 120px;\n  min-height: 70px;\n  --border-radius: 5%; }\n  .item ion-thumbnail img {\n    min-width: 120px;\n    min-height: 70px; }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcGFnZXMvaG9tZS9EOlxcV29ya3NwYWNlXFxpb25pY1xcdGlyaXBvbi1zcGVha2VyLWFwcC9zcmNcXGFwcFxccGFnZXNcXGhvbWVcXGhvbWUucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0UsZ0JBQWdCO0VBQ2hCLGdCQUFnQjtFQUtoQixtQkFBZ0IsRUFBQTtFQVBsQjtJQUlJLGdCQUFnQjtJQUNoQixnQkFBZ0IsRUFBQSIsImZpbGUiOiJzcmMvYXBwL3BhZ2VzL2hvbWUvaG9tZS5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIuaXRlbSBpb24tdGh1bWJuYWlsIHtcclxuICBtaW4td2lkdGg6IDEyMHB4OyAgICBcclxuICBtaW4taGVpZ2h0OiA3MHB4O1xyXG4gIGltZyB7XHJcbiAgICBtaW4td2lkdGg6IDEyMHB4OyAgICBcclxuICAgIG1pbi1oZWlnaHQ6IDcwcHg7IFxyXG4gIH1cclxuICAtLWJvcmRlci1yYWRpdXM6IDUlO1xyXG59Il19 */"

/***/ }),

/***/ "./src/app/pages/home/home.page.ts":
/*!*****************************************!*\
  !*** ./src/app/pages/home/home.page.ts ***!
  \*****************************************/
/*! exports provided: HomePage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "HomePage", function() { return HomePage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _services_api_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../services/api.service */ "./src/app/services/api.service.ts");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");




var HomePage = /** @class */ (function () {
    function HomePage(apiService, navController) {
        this.apiService = apiService;
        this.navController = navController;
        this.baseUrl = 'https://www.tiripon.net/assets/event_image/landing/';
        this.skeletonItems = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10];
    }
    HomePage.prototype.ngOnInit = function () {
        //this.getEvents();
    };
    HomePage.prototype.ionViewWillEnter = function () {
        this.getEvents();
    };
    HomePage.prototype.getEvents = function () {
        var _this = this;
        this.apiService.getEvents().then(function (events) {
            if (_this.hasEvents(events)) {
                //alert(JSON.stringify(events));
                _this.events = events;
            }
            else {
                _this.events = [];
            }
        });
    };
    HomePage.prototype.hasEvents = function (events) {
        var numberOfEvents = events.length;
        if (numberOfEvents >= 1) {
            return true;
        }
        else {
            return false;
        }
    };
    HomePage.prototype.navigateToEventPage = function (event) {
        var parameters = {
            queryParams: event
        };
        //alert(JSON.stringify(event));
        this.navController.navigateForward(['/event'], parameters);
    };
    HomePage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-home',
            template: __webpack_require__(/*! ./home.page.html */ "./src/app/pages/home/home.page.html"),
            styles: [__webpack_require__(/*! ./home.page.scss */ "./src/app/pages/home/home.page.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_services_api_service__WEBPACK_IMPORTED_MODULE_2__["ApiService"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["NavController"]])
    ], HomePage);
    return HomePage;
}());



/***/ })

}]);
//# sourceMappingURL=pages-home-home-module.js.map