(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["pages-login-login-module"],{

/***/ "./src/app/pages/login/login.module.ts":
/*!*********************************************!*\
  !*** ./src/app/pages/login/login.module.ts ***!
  \*********************************************/
/*! exports provided: LoginPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LoginPageModule", function() { return LoginPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _login_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./login.page */ "./src/app/pages/login/login.page.ts");







var routes = [
    {
        path: '',
        component: _login_page__WEBPACK_IMPORTED_MODULE_6__["LoginPage"]
    }
];
var LoginPageModule = /** @class */ (function () {
    function LoginPageModule() {
    }
    LoginPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["ReactiveFormsModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterModule"].forChild(routes)
            ],
            declarations: [_login_page__WEBPACK_IMPORTED_MODULE_6__["LoginPage"]]
        })
    ], LoginPageModule);
    return LoginPageModule;
}());



/***/ }),

/***/ "./src/app/pages/login/login.page.html":
/*!*********************************************!*\
  !*** ./src/app/pages/login/login.page.html ***!
  \*********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-content padding>\n  <ion-grid>\n    <ion-img class=\"img-size\" src=\"assets/images/tiripon_speaker_logo.png\"></ion-img>\n    <!-- LOGO / BANNER--> \n\n    <!-- LOGIN FORM -->\n     \n  <form> \n    <ion-item lines=\"none\">\n      <ion-input name=\"email\" placeholder=\"Email\" type=\"email\" [(ngModel)]=\"email\">\n        <ion-icon class=\"icon-margin\" name=\"mail\" slot=\"end\" value=\"dropchase1@gmail.com\"></ion-icon>\n      </ion-input>\n    </ion-item> \n    \n    <ion-item lines=\"none\">\n      <ion-input name=\"password\" placeholder=\"Password\" type=\"password\" [(ngModel)]=\"password\">\n        <ion-icon class=\"icon-margin\" name=\"lock\" slot=\"end\" value=\"Salesletter123Salesletter123\"></ion-icon>\n      </ion-input> \n    </ion-item>\n\n    <br>\n    <!-- <ion-button [disabled]=\"hasNoInputs()\" color=\"medium\" type=\"submit\" expand=\"block\" shape=\"round\" (click)=\"login()\">Login</ion-button> -->\n    <ion-button [disabled]=\"hasNoInputs()\" color=\"medium\" type=\"submit\" expand=\"block\" shape=\"round\" (click)=\"login()\">Login</ion-button>\n  </form>\n     \n\n    <!-- LOGIN VIA FACEBOOK OR GOOGLE -->\n  <ion-item lines=\"none\" text-center>\n    <ion-label>OR</ion-label>\n  </ion-item>\n \n  <ion-button class=\"facebook-button\" expand=\"block\" shape=\"round\" (click)=\"loginWithFacebook()\">\n    <ion-icon name=\"logo-facebook\" slot=\"start\"></ion-icon> \n    <ion-label>FACEBOOK</ion-label>\n  </ion-button> \n      <!--<ion-col size=\"6\">\n        <ion-button color=\"warning\" expand=\"block\" fill=\"outline\" shape=\"round\" (click)=\"loginViaGoogleAccount()\">\n          <ion-icon name=\"logo-google\" slot=\"start\"></ion-icon> \n          <ion-label>GOOGLE</ion-label>\n        </ion-button>\n      </ion-col>-->   \n  </ion-grid>\n  <!--<button onclick=\"window.plugins.googleplus.getSigningCertificateFingerprint(function(res){alert(res)}, function(res){alert(res)})\">get cert fingerprint (Android)</button>-->\n</ion-content>\n"

/***/ }),

/***/ "./src/app/pages/login/login.page.scss":
/*!*********************************************!*\
  !*** ./src/app/pages/login/login.page.scss ***!
  \*********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".img-size {\n  height: 13vh !important;\n  width: auto !important;\n  margin: 10%;\n  display: block; }\n\n.facebook-button {\n  --background:#3b5998;\n  --color: white; }\n\n.icon-margin {\n  margin: 3%; }\n\n.item, .list, .item-content, .item-complex {\n  --ion-background-color: transparent !important;\n  --color: white; }\n\nion-content {\n  --background: #fff url('/assets/images/speaker-login.png') no-repeat center center / cover; }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcGFnZXMvbG9naW4vRDpcXFdvcmtzcGFjZVxcaW9uaWNcXHRpcmlwb24tc3BlYWtlci1hcHAvc3JjXFxhcHBcXHBhZ2VzXFxsb2dpblxcbG9naW4ucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0ksdUJBQXVCO0VBQ3ZCLHNCQUFzQjtFQUN0QixXQUFXO0VBQ1gsY0FBYyxFQUFBOztBQUdsQjtFQUNJLG9CQUFhO0VBQ2IsY0FBUSxFQUFBOztBQUdaO0VBQ0ksVUFBVSxFQUFBOztBQUdkO0VBQ0ksOENBQXVCO0VBQ3ZCLGNBQVEsRUFBQTs7QUFHWjtFQUNJLDBGQUFhLEVBQUEiLCJmaWxlIjoic3JjL2FwcC9wYWdlcy9sb2dpbi9sb2dpbi5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIuaW1nLXNpemUge1xyXG4gICAgaGVpZ2h0OiAxM3ZoICFpbXBvcnRhbnQ7XHJcbiAgICB3aWR0aDogYXV0byAhaW1wb3J0YW50O1xyXG4gICAgbWFyZ2luOiAxMCU7XHJcbiAgICBkaXNwbGF5OiBibG9jaztcclxufVxyXG5cclxuLmZhY2Vib29rLWJ1dHRvbntcclxuICAgIC0tYmFja2dyb3VuZDojM2I1OTk4O1xyXG4gICAgLS1jb2xvcjogd2hpdGU7XHJcbn0gXHJcblxyXG4uaWNvbi1tYXJnaW57XHJcbiAgICBtYXJnaW46IDMlO1xyXG59XHJcblxyXG4uaXRlbSwgLmxpc3QsIC5pdGVtLWNvbnRlbnQsIC5pdGVtLWNvbXBsZXgge1xyXG4gICAgLS1pb24tYmFja2dyb3VuZC1jb2xvcjogdHJhbnNwYXJlbnQgIWltcG9ydGFudDtcclxuICAgIC0tY29sb3I6IHdoaXRlO1xyXG59XHJcblxyXG5pb24tY29udGVudHtcclxuICAgIC0tYmFja2dyb3VuZDogI2ZmZiB1cmwoJy9hc3NldHMvaW1hZ2VzL3NwZWFrZXItbG9naW4ucG5nJykgbm8tcmVwZWF0IGNlbnRlciBjZW50ZXIgLyBjb3ZlcjtcclxufSJdfQ== */"

/***/ }),

/***/ "./src/app/pages/login/login.page.ts":
/*!*******************************************!*\
  !*** ./src/app/pages/login/login.page.ts ***!
  \*******************************************/
/*! exports provided: LoginPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LoginPage", function() { return LoginPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _ionic_native_google_plus_ngx__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic-native/google-plus/ngx */ "./node_modules/@ionic-native/google-plus/ngx/index.js");
/* harmony import */ var _ionic_native_facebook_ngx__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic-native/facebook/ngx */ "./node_modules/@ionic-native/facebook/ngx/index.js");
/* harmony import */ var _services_api_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../services/api.service */ "./src/app/services/api.service.ts");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _ionic_storage__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic/storage */ "./node_modules/@ionic/storage/fesm5/ionic-storage.js");









var LoginPage = /** @class */ (function () {
    function LoginPage(alertController, apiService, facebook, googlePlus, loadingController, navController, platform, formBuilder, storage) {
        this.alertController = alertController;
        this.apiService = apiService;
        this.facebook = facebook;
        this.googlePlus = googlePlus;
        this.loadingController = loadingController;
        this.navController = navController;
        this.platform = platform;
        this.formBuilder = formBuilder;
        this.storage = storage;
        this.email = 'dropchase1@gmail.com';
        this.password = 'Salesletter123Salesletter123';
    }
    LoginPage.prototype.ngOnInit = function () {
    };
    LoginPage.prototype.ionViewWillEnter = function () {
        //this.setTextboxesToEmpty();
    };
    LoginPage.prototype.presentAlert = function (options) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var alert;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.alertController.create({
                            header: options.header,
                            message: options.message,
                            buttons: ['OK']
                        })];
                    case 1:
                        alert = _a.sent();
                        return [4 /*yield*/, alert.present()];
                    case 2:
                        _a.sent();
                        return [2 /*return*/];
                }
            });
        });
    };
    LoginPage.prototype.displayPage = function (name) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.navController.navigateForward('/' + name)];
                    case 1:
                        _a.sent();
                        return [2 /*return*/];
                }
            });
        });
    };
    LoginPage.prototype.presentLoading = function (message) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var options, _a;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_b) {
                switch (_b.label) {
                    case 0:
                        options = {
                            message: message
                        };
                        _a = this;
                        return [4 /*yield*/, this.loadingController.create(options)];
                    case 1:
                        _a.loading = _b.sent();
                        return [4 /*yield*/, this.loading.present()];
                    case 2:
                        _b.sent();
                        return [2 /*return*/];
                }
            });
        });
    };
    LoginPage.prototype.dismissLoading = function () {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.loading.dismiss()];
                    case 1:
                        _a.sent();
                        return [2 /*return*/];
                }
            });
        });
    };
    LoginPage.prototype.setTextboxesToEmpty = function () {
        this.email = '';
        this.password = '';
    };
    LoginPage.prototype.loginWithFacebook = function () {
        var _this = this;
        //this.platform.ready().then(() => {
        // this.logoutFacebookAccount(); return;
        this.facebook.login(['public_profile', 'email']).then(function (response) {
            //alert(JSON.stringify(response));
            var userId = response.authResponse.userID;
            _this.presentLoading('Logging into your account.').then(function () {
                _this.getFacebookUser(userId).then(function (facebookUser) {
                    //alert(JSON.stringify(facebookUser));
                    _this.apiService.getTiriponFacebookUser(facebookUser).then(function (user) {
                        //alert(JSON.stringify(user));
                        if (_this.doesUserExists(user)) {
                            user = user[0];
                            _this.storage.set('user', user);
                            _this.storage.get('user').then(function (user) {
                                //alert(JSON.stringify(user)); 
                                _this.storage.set('isLogin', true).then(function () {
                                    _this.displayPage('home');
                                });
                            });
                        }
                        else {
                            var options = {
                                header: 'Facebook Login',
                                message: 'We could not find a <strong>Tiripon account</strong> associated with this Facebook ' +
                                    'login. Please register an account.'
                            };
                            _this.presentAlert(options).then(function () {
                                _this.setTextboxesToEmpty();
                            });
                        }
                        _this.dismissLoading();
                        // this.logoutFacebookAccount();
                    });
                });
            });
        })
            .catch(function (response) {
            // let wasFacebookLoginCancelled = response.errorCode === '4201' && response.errorMessage === 'User cancelled dialog';
            // if (wasFacebookLoginCancelled) {
            //   alert(response);
            // }
        });
        this.facebook.logEvent(this.facebook.EVENTS.EVENT_NAME_ADDED_TO_CART);
        //});   
    };
    LoginPage.prototype.getFacebookUser = function (userId) {
        var _this = this;
        return new Promise(function (resolve, reject) {
            var requestPath = '/' + userId + '/?fields=id,email,first_name,middle_name,last_name';
            var permissions = ['public_profile'];
            _this.facebook.api(requestPath, permissions).then(function (user) {
                resolve(user);
            });
        });
    };
    LoginPage.prototype.logoutFacebookAccount = function () {
        var _this = this;
        return new Promise(function (resolve, reject) {
            _this.facebook.logout().then(function (result) {
                resolve(result);
            }, function (error) {
                reject(error);
            });
        });
    };
    LoginPage.prototype.loginViaGoogleAccount = function () {
        //this.platform.ready().then(() => { 
        this.googlePlus.login({})
            .then(function (res) {
            alert('Success!');
            alert(JSON.stringify(res));
        })
            .catch(function (err) {
            alert('Faiel!');
            alert(JSON.stringify(err));
        });
        //});
    };
    LoginPage.prototype.hasNoInputs = function () {
        if (this.email === '' || this.password === '') {
            return true;
        }
    };
    LoginPage.prototype.login = function () {
        var _this = this;
        var isEmailEmpty = this.email === '';
        var isPasswordEmpty = this.password === '';
        /*if (isEmailEmpty) {
          //alert(1);
          return;
        } */
        var credentials = {
            email: this.email,
            password: this.password
        };
        this.presentLoading('Logging into your account...');
        // const credentials = {
        //   email: 'salesletter123@gmail.com',
        //   password: 'Salesletter123Salesletter123'
        // }
        this.apiService.getUser(credentials).then(function (user) {
            //alert(JSON.stringify(user));
            if (_this.doesUserExists(user)) {
                _this.storage.set('isLogin', true).then(function () {
                    _this.storage.set('user', user).then(function () {
                        _this.dismissLoading().then(function () {
                            _this.displayPage('home');
                        });
                    });
                });
            }
            else {
                _this.dismissLoading().then(function () {
                    var options = {
                        header: 'Login',
                        message: 'Incorrect username and password.'
                    };
                    _this.presentAlert(options).then(function () {
                        _this.setTextboxesToEmpty();
                    });
                });
            }
        });
    };
    LoginPage.prototype.functionName = function () {
        alert(1);
    };
    // public logoutAccount() {
    //   this.storage.clear().then(response => {
    //     alert(JSON.stringify(response));
    //     this.navController.navigateBack(['/login']);
    //   });
    // }
    // public async showConfirmLogout() {
    //   const alert = await this.alertController.create({
    //     header: 'Confirm Logout',
    //     message: 'Do you want to logout your Tiripon account?',
    //     buttons: [
    //       {
    //         text: 'Cancel',
    //         role: 'cancel',
    //         cssClass: 'secondary'
    //       }, {
    //         text: 'Logout',
    //         cssClass: 'secondary',
    //         handler: () => { 
    //           this.logoutAccount();
    //         }
    //       }
    //     ]
    //   });
    //   await alert.present();
    // }
    LoginPage.prototype.doesUserExists = function (user) {
        if (user.length === 1) {
            return true;
        }
        else {
            return false;
        }
    };
    LoginPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-login',
            template: __webpack_require__(/*! ./login.page.html */ "./src/app/pages/login/login.page.html"),
            styles: [__webpack_require__(/*! ./login.page.scss */ "./src/app/pages/login/login.page.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_2__["AlertController"],
            _services_api_service__WEBPACK_IMPORTED_MODULE_5__["ApiService"],
            _ionic_native_facebook_ngx__WEBPACK_IMPORTED_MODULE_4__["Facebook"],
            _ionic_native_google_plus_ngx__WEBPACK_IMPORTED_MODULE_3__["GooglePlus"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["LoadingController"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["NavController"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["Platform"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_6__["FormBuilder"],
            _ionic_storage__WEBPACK_IMPORTED_MODULE_7__["Storage"]])
    ], LoginPage);
    return LoginPage;
}());



/***/ })

}]);
//# sourceMappingURL=pages-login-login-module.js.map