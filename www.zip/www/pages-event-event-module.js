(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["pages-event-event-module"],{

/***/ "./src/app/pages/event/event.module.ts":
/*!*********************************************!*\
  !*** ./src/app/pages/event/event.module.ts ***!
  \*********************************************/
/*! exports provided: EventPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "EventPageModule", function() { return EventPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _event_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./event.page */ "./src/app/pages/event/event.page.ts");







var routes = [
    {
        path: '',
        component: _event_page__WEBPACK_IMPORTED_MODULE_6__["EventPage"]
    }
];
var EventPageModule = /** @class */ (function () {
    function EventPageModule() {
    }
    EventPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterModule"].forChild(routes)
            ],
            declarations: [_event_page__WEBPACK_IMPORTED_MODULE_6__["EventPage"]]
        })
    ], EventPageModule);
    return EventPageModule;
}());



/***/ }),

/***/ "./src/app/pages/event/event.page.html":
/*!*********************************************!*\
  !*** ./src/app/pages/event/event.page.html ***!
  \*********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header>\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <ion-back-button defaultHref=\"/events\"></ion-back-button> \n    </ion-buttons>\n    <ion-title style=\"font-weight: 400;\">Event details</ion-title>\n    <!-- <ion-buttons slot=\"end\">\n      <ion-button>\n        <ion-icon name=\"share\"></ion-icon>\n      </ion-button>\n    </ion-buttons>  -->\n  </ion-toolbar>\n</ion-header>\n<ion-img src=\"{{ baseUrl + event.event_image_path }}\"></ion-img>\n<ion-content padding-start padding-end>  \n  <h1 style=\"font-weight: 400\">{{ event.event_title }}</h1> \n  <ion-badge color=\"medium\"><small>{{ event.event_type }}</small></ion-badge>\n  <p [innerHTML]=\"event.event_description\"></p> \n   \n  <ion-item>\n    <ion-icon name=\"calendar\" slot=\"start\"></ion-icon>\n    <ion-label>\n      <p style=\"font-weight: 350; color: black; font-size: 16px;\">Start: {{ event.start | date : \"mediumDate\" }} at {{ event.start | date : \"shortTime\" }}</p>\n      <p style=\"font-weight: 350; color: black; font-size: 16px;\">End: {{ event.end | date : \"mediumDate\" }} at {{ event.end | date : \"shortTime\" }}</p>\n    </ion-label>\n  </ion-item> \n  <ion-item>\n    <ion-icon name=\"pin\" slot=\"start\"></ion-icon>\n    <ion-label>\n      <p style=\"font-weight: 350; color: black; font-size: 16px;\">{{ event.province }}, {{ event.country }}</p>\n      <p style=\"font-weight: 350; font-size: 12px;\">{{ event.street }}, {{ event.city }}</p>\n    </ion-label>\n  </ion-item>    \n  \n</ion-content>\n"

/***/ }),

/***/ "./src/app/pages/event/event.page.scss":
/*!*********************************************!*\
  !*** ./src/app/pages/event/event.page.scss ***!
  \*********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3BhZ2VzL2V2ZW50L2V2ZW50LnBhZ2Uuc2NzcyJ9 */"

/***/ }),

/***/ "./src/app/pages/event/event.page.ts":
/*!*******************************************!*\
  !*** ./src/app/pages/event/event.page.ts ***!
  \*******************************************/
/*! exports provided: EventPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "EventPage", function() { return EventPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");



var EventPage = /** @class */ (function () {
    function EventPage(route) {
        this.route = route;
        this.baseUrl = 'https://www.tiripon.net/assets/event_image/landing/';
    }
    EventPage.prototype.ngOnInit = function () {
        var _this = this;
        this.getEvent().then(function (event) {
            _this.event = event;
        });
    };
    EventPage.prototype.getEvent = function () {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var _this = this;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                return [2 /*return*/, new Promise(function (resolve, reject) {
                        _this.route.queryParams.subscribe(function (params) {
                            resolve(params);
                        }, function (error) {
                            reject(error);
                        });
                    })];
            });
        });
    };
    EventPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-event',
            template: __webpack_require__(/*! ./event.page.html */ "./src/app/pages/event/event.page.html"),
            styles: [__webpack_require__(/*! ./event.page.scss */ "./src/app/pages/event/event.page.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"]])
    ], EventPage);
    return EventPage;
}());



/***/ })

}]);
//# sourceMappingURL=pages-event-event-module.js.map