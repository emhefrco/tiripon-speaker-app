(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["pages-event-chats-event-chats-module"],{

/***/ "./src/app/pages/event-chats/event-chats.module.ts":
/*!*********************************************************!*\
  !*** ./src/app/pages/event-chats/event-chats.module.ts ***!
  \*********************************************************/
/*! exports provided: EventChatsPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "EventChatsPageModule", function() { return EventChatsPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _event_chats_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./event-chats.page */ "./src/app/pages/event-chats/event-chats.page.ts");







var routes = [
    {
        path: '',
        component: _event_chats_page__WEBPACK_IMPORTED_MODULE_6__["EventChatsPage"]
    }
];
var EventChatsPageModule = /** @class */ (function () {
    function EventChatsPageModule() {
    }
    EventChatsPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterModule"].forChild(routes)
            ],
            declarations: [_event_chats_page__WEBPACK_IMPORTED_MODULE_6__["EventChatsPage"]]
        })
    ], EventChatsPageModule);
    return EventChatsPageModule;
}());



/***/ }),

/***/ "./src/app/pages/event-chats/event-chats.page.html":
/*!*********************************************************!*\
  !*** ./src/app/pages/event-chats/event-chats.page.html ***!
  \*********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header>\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <ion-back-button defaultHref=\"/home\"></ion-back-button> \n    </ion-buttons>\n    <ion-title style=\"font-weight: 400;\">Event chats</ion-title> \n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <ion-list *ngIf=\"events\" color=\"light\"> \n    <ion-item class=\"item\" *ngFor=\"let event of events\" (click)=\"navigateToEventPage(event)\" lines=\"none\" button>\n      <ion-ripple-effect type=\"bounded\"></ion-ripple-effect>\n      <ion-thumbnail slot=\"start\">\n        <ion-img src=\"{{ baseUrl + event.event_image_path }}\"></ion-img>\n      </ion-thumbnail>\n      <ion-label>\n        <p style=\"color: black; font-size: 16px; font-weight: 350;\"> \n          {{ event.event_title }}\n        </p>\n        <p style=\"font-size: 12px; font-weight: 300;\"> \n          {{ event.province }}, {{ event.country }} \n        </p> \n        <p style=\"font-size: 12px; font-weight: 300;\">  \n          {{ event.start | date : \"mediumDate\" }} \n        </p> \n      </ion-label> \n    </ion-item>    \n  </ion-list>\n</ion-content>\n"

/***/ }),

/***/ "./src/app/pages/event-chats/event-chats.page.scss":
/*!*********************************************************!*\
  !*** ./src/app/pages/event-chats/event-chats.page.scss ***!
  \*********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3BhZ2VzL2V2ZW50LWNoYXRzL2V2ZW50LWNoYXRzLnBhZ2Uuc2NzcyJ9 */"

/***/ }),

/***/ "./src/app/pages/event-chats/event-chats.page.ts":
/*!*******************************************************!*\
  !*** ./src/app/pages/event-chats/event-chats.page.ts ***!
  \*******************************************************/
/*! exports provided: EventChatsPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "EventChatsPage", function() { return EventChatsPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _services_api_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../services/api.service */ "./src/app/services/api.service.ts");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");




var EventChatsPage = /** @class */ (function () {
    function EventChatsPage(apiService, navController) {
        this.apiService = apiService;
        this.navController = navController;
        this.events = [];
        this.baseUrl = 'https://www.tiripon.net/assets/dashboard/images/speaker/material/images/';
    }
    EventChatsPage.prototype.ngOnInit = function () {
        this.getEvents();
    };
    EventChatsPage.prototype.getEvents = function () {
        var _this = this;
        //this.presentLoading('').then(() => {
        this.apiService.getEvents().then(function (events) {
            if (_this.hasEvents(events)) {
                //alert(1);
                _this.events = events;
                //alert(JSON.stringify(this.events));
            }
            else {
                //alert(2);
                _this.events = [];
            }
        });
        //}); 
    };
    EventChatsPage.prototype.hasEvents = function (events) {
        var numberOfEvents = events.length;
        if (numberOfEvents >= 1) {
            return true;
        }
        else {
            return false;
        }
    };
    EventChatsPage.prototype.navigateToEventPage = function (event) {
        var parameters = {
            queryParams: event
        };
        //alert(JSON.stringify(event));
        this.navController.navigateForward(['/event-chat'], parameters);
    };
    EventChatsPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-event-chats',
            template: __webpack_require__(/*! ./event-chats.page.html */ "./src/app/pages/event-chats/event-chats.page.html"),
            styles: [__webpack_require__(/*! ./event-chats.page.scss */ "./src/app/pages/event-chats/event-chats.page.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_services_api_service__WEBPACK_IMPORTED_MODULE_2__["ApiService"], _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["NavController"]])
    ], EventChatsPage);
    return EventChatsPage;
}());



/***/ })

}]);
//# sourceMappingURL=pages-event-chats-event-chats-module.js.map