(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["main"],{

/***/ "./node_modules/@ionic/core/dist/esm/legacy lazy recursive ^\\.\\/.*\\.entry\\.js$ include: \\.entry\\.js$ exclude: \\.system\\.entry\\.js$":
/*!************************************************************************************************************************************************!*\
  !*** ./node_modules/@ionic/core/dist/esm/legacy lazy ^\.\/.*\.entry\.js$ include: \.entry\.js$ exclude: \.system\.entry\.js$ namespace object ***!
  \************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var map = {
	"./ion-action-sheet-controller_7.entry.js": [
		"./node_modules/@ionic/core/dist/esm/legacy/ion-action-sheet-controller_7.entry.js",
		13
	],
	"./ion-action-sheet-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm/legacy/ion-action-sheet-ios.entry.js",
		"common",
		14
	],
	"./ion-action-sheet-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm/legacy/ion-action-sheet-md.entry.js",
		"common",
		15
	],
	"./ion-alert-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm/legacy/ion-alert-ios.entry.js",
		"common",
		16
	],
	"./ion-alert-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm/legacy/ion-alert-md.entry.js",
		"common",
		17
	],
	"./ion-anchor_6.entry.js": [
		"./node_modules/@ionic/core/dist/esm/legacy/ion-anchor_6.entry.js",
		1,
		"common",
		18
	],
	"./ion-app_7-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm/legacy/ion-app_7-ios.entry.js",
		"common",
		19
	],
	"./ion-app_7-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm/legacy/ion-app_7-md.entry.js",
		"common",
		20
	],
	"./ion-avatar_3-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm/legacy/ion-avatar_3-ios.entry.js",
		"common",
		21
	],
	"./ion-avatar_3-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm/legacy/ion-avatar_3-md.entry.js",
		"common",
		22
	],
	"./ion-back-button-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm/legacy/ion-back-button-ios.entry.js",
		"common",
		23
	],
	"./ion-back-button-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm/legacy/ion-back-button-md.entry.js",
		"common",
		24
	],
	"./ion-backdrop-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm/legacy/ion-backdrop-ios.entry.js",
		0,
		"common",
		25
	],
	"./ion-backdrop-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm/legacy/ion-backdrop-md.entry.js",
		0,
		"common",
		26
	],
	"./ion-button_2-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm/legacy/ion-button_2-ios.entry.js",
		"common",
		27
	],
	"./ion-button_2-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm/legacy/ion-button_2-md.entry.js",
		"common",
		28
	],
	"./ion-card_5-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm/legacy/ion-card_5-ios.entry.js",
		"common",
		29
	],
	"./ion-card_5-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm/legacy/ion-card_5-md.entry.js",
		"common",
		30
	],
	"./ion-checkbox-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm/legacy/ion-checkbox-ios.entry.js",
		"common",
		31
	],
	"./ion-checkbox-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm/legacy/ion-checkbox-md.entry.js",
		"common",
		32
	],
	"./ion-chip-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm/legacy/ion-chip-ios.entry.js",
		"common",
		33
	],
	"./ion-chip-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm/legacy/ion-chip-md.entry.js",
		"common",
		34
	],
	"./ion-col_3.entry.js": [
		"./node_modules/@ionic/core/dist/esm/legacy/ion-col_3.entry.js",
		35
	],
	"./ion-datetime_3-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm/legacy/ion-datetime_3-ios.entry.js",
		"common",
		36
	],
	"./ion-datetime_3-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm/legacy/ion-datetime_3-md.entry.js",
		"common",
		37
	],
	"./ion-fab_3-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm/legacy/ion-fab_3-ios.entry.js",
		"common",
		38
	],
	"./ion-fab_3-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm/legacy/ion-fab_3-md.entry.js",
		"common",
		39
	],
	"./ion-img.entry.js": [
		"./node_modules/@ionic/core/dist/esm/legacy/ion-img.entry.js",
		40
	],
	"./ion-infinite-scroll_2-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm/legacy/ion-infinite-scroll_2-ios.entry.js",
		"common",
		41
	],
	"./ion-infinite-scroll_2-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm/legacy/ion-infinite-scroll_2-md.entry.js",
		"common",
		42
	],
	"./ion-input-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm/legacy/ion-input-ios.entry.js",
		"common",
		43
	],
	"./ion-input-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm/legacy/ion-input-md.entry.js",
		"common",
		44
	],
	"./ion-item-option_3-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm/legacy/ion-item-option_3-ios.entry.js",
		"common",
		45
	],
	"./ion-item-option_3-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm/legacy/ion-item-option_3-md.entry.js",
		"common",
		46
	],
	"./ion-item_8-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm/legacy/ion-item_8-ios.entry.js",
		"common",
		47
	],
	"./ion-item_8-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm/legacy/ion-item_8-md.entry.js",
		"common",
		48
	],
	"./ion-loading-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm/legacy/ion-loading-ios.entry.js",
		"common",
		49
	],
	"./ion-loading-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm/legacy/ion-loading-md.entry.js",
		"common",
		50
	],
	"./ion-menu_4-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm/legacy/ion-menu_4-ios.entry.js",
		0,
		"common",
		51
	],
	"./ion-menu_4-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm/legacy/ion-menu_4-md.entry.js",
		0,
		"common",
		52
	],
	"./ion-modal-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm/legacy/ion-modal-ios.entry.js",
		1,
		"common",
		53
	],
	"./ion-modal-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm/legacy/ion-modal-md.entry.js",
		1,
		"common",
		54
	],
	"./ion-nav_4.entry.js": [
		"./node_modules/@ionic/core/dist/esm/legacy/ion-nav_4.entry.js",
		1,
		"common",
		55
	],
	"./ion-popover-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm/legacy/ion-popover-ios.entry.js",
		1,
		"common",
		56
	],
	"./ion-popover-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm/legacy/ion-popover-md.entry.js",
		1,
		"common",
		57
	],
	"./ion-progress-bar-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm/legacy/ion-progress-bar-ios.entry.js",
		"common",
		58
	],
	"./ion-progress-bar-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm/legacy/ion-progress-bar-md.entry.js",
		"common",
		59
	],
	"./ion-radio_2-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm/legacy/ion-radio_2-ios.entry.js",
		"common",
		60
	],
	"./ion-radio_2-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm/legacy/ion-radio_2-md.entry.js",
		"common",
		61
	],
	"./ion-range-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm/legacy/ion-range-ios.entry.js",
		"common",
		62
	],
	"./ion-range-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm/legacy/ion-range-md.entry.js",
		"common",
		63
	],
	"./ion-refresher_2-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm/legacy/ion-refresher_2-ios.entry.js",
		"common",
		64
	],
	"./ion-refresher_2-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm/legacy/ion-refresher_2-md.entry.js",
		"common",
		65
	],
	"./ion-reorder_2-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm/legacy/ion-reorder_2-ios.entry.js",
		"common",
		66
	],
	"./ion-reorder_2-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm/legacy/ion-reorder_2-md.entry.js",
		"common",
		67
	],
	"./ion-ripple-effect.entry.js": [
		"./node_modules/@ionic/core/dist/esm/legacy/ion-ripple-effect.entry.js",
		68
	],
	"./ion-searchbar-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm/legacy/ion-searchbar-ios.entry.js",
		"common",
		69
	],
	"./ion-searchbar-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm/legacy/ion-searchbar-md.entry.js",
		"common",
		70
	],
	"./ion-segment_2-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm/legacy/ion-segment_2-ios.entry.js",
		"common",
		71
	],
	"./ion-segment_2-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm/legacy/ion-segment_2-md.entry.js",
		"common",
		72
	],
	"./ion-select_3-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm/legacy/ion-select_3-ios.entry.js",
		"common",
		73
	],
	"./ion-select_3-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm/legacy/ion-select_3-md.entry.js",
		"common",
		74
	],
	"./ion-slide_2-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm/legacy/ion-slide_2-ios.entry.js",
		"common",
		75
	],
	"./ion-slide_2-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm/legacy/ion-slide_2-md.entry.js",
		"common",
		76
	],
	"./ion-spinner.entry.js": [
		"./node_modules/@ionic/core/dist/esm/legacy/ion-spinner.entry.js",
		"common",
		77
	],
	"./ion-split-pane-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm/legacy/ion-split-pane-ios.entry.js",
		78
	],
	"./ion-split-pane-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm/legacy/ion-split-pane-md.entry.js",
		79
	],
	"./ion-tab-bar_2-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm/legacy/ion-tab-bar_2-ios.entry.js",
		"common",
		80
	],
	"./ion-tab-bar_2-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm/legacy/ion-tab-bar_2-md.entry.js",
		"common",
		81
	],
	"./ion-tab_2.entry.js": [
		"./node_modules/@ionic/core/dist/esm/legacy/ion-tab_2.entry.js",
		"common",
		10
	],
	"./ion-text.entry.js": [
		"./node_modules/@ionic/core/dist/esm/legacy/ion-text.entry.js",
		"common",
		82
	],
	"./ion-textarea-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm/legacy/ion-textarea-ios.entry.js",
		"common",
		83
	],
	"./ion-textarea-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm/legacy/ion-textarea-md.entry.js",
		"common",
		84
	],
	"./ion-toast-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm/legacy/ion-toast-ios.entry.js",
		"common",
		85
	],
	"./ion-toast-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm/legacy/ion-toast-md.entry.js",
		"common",
		86
	],
	"./ion-toggle-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm/legacy/ion-toggle-ios.entry.js",
		"common",
		87
	],
	"./ion-toggle-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm/legacy/ion-toggle-md.entry.js",
		"common",
		88
	],
	"./ion-virtual-scroll.entry.js": [
		"./node_modules/@ionic/core/dist/esm/legacy/ion-virtual-scroll.entry.js",
		89
	]
};
function webpackAsyncContext(req) {
	var ids = map[req];
	if(!ids) {
		return Promise.resolve().then(function() {
			var e = new Error("Cannot find module '" + req + "'");
			e.code = 'MODULE_NOT_FOUND';
			throw e;
		});
	}
	return Promise.all(ids.slice(1).map(__webpack_require__.e)).then(function() {
		var id = ids[0];
		return __webpack_require__(id);
	});
}
webpackAsyncContext.keys = function webpackAsyncContextKeys() {
	return Object.keys(map);
};
webpackAsyncContext.id = "./node_modules/@ionic/core/dist/esm/legacy lazy recursive ^\\.\\/.*\\.entry\\.js$ include: \\.entry\\.js$ exclude: \\.system\\.entry\\.js$";
module.exports = webpackAsyncContext;

/***/ }),

/***/ "./src/$$_lazy_route_resource lazy recursive":
/*!**********************************************************!*\
  !*** ./src/$$_lazy_route_resource lazy namespace object ***!
  \**********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var map = {
	"./pages/event-chat-general/event-chat-general.module": [
		"./src/app/pages/event-chat-general/event-chat-general.module.ts",
		"pages-event-chat-general-event-chat-general-module"
	],
	"./pages/event-chat/event-chat.module": [
		"./src/app/pages/event-chat/event-chat.module.ts",
		"pages-event-chat-event-chat-module"
	],
	"./pages/event-chats/event-chats.module": [
		"./src/app/pages/event-chats/event-chats.module.ts",
		"common",
		"pages-event-chats-event-chats-module"
	],
	"./pages/event-materials/event-materials.module": [
		"./src/app/pages/event-materials/event-materials.module.ts",
		"common",
		"pages-event-materials-event-materials-module"
	],
	"./pages/event/event.module": [
		"./src/app/pages/event/event.module.ts",
		"pages-event-event-module"
	],
	"./pages/events/events.module": [
		"./src/app/pages/events/events.module.ts",
		"common",
		"pages-events-events-module"
	],
	"./pages/home/home.module": [
		"./src/app/pages/home/home.module.ts",
		"common",
		"pages-home-home-module"
	],
	"./pages/login/login.module": [
		"./src/app/pages/login/login.module.ts",
		"common",
		"pages-login-login-module"
	],
	"./pages/materials/materials.module": [
		"./src/app/pages/materials/materials.module.ts",
		"common",
		"pages-materials-materials-module"
	],
	"./pages/profile/profile.module": [
		"./src/app/pages/profile/profile.module.ts",
		"pages-profile-profile-module"
	]
};
function webpackAsyncContext(req) {
	var ids = map[req];
	if(!ids) {
		return Promise.resolve().then(function() {
			var e = new Error("Cannot find module '" + req + "'");
			e.code = 'MODULE_NOT_FOUND';
			throw e;
		});
	}
	return Promise.all(ids.slice(1).map(__webpack_require__.e)).then(function() {
		var id = ids[0];
		return __webpack_require__(id);
	});
}
webpackAsyncContext.keys = function webpackAsyncContextKeys() {
	return Object.keys(map);
};
webpackAsyncContext.id = "./src/$$_lazy_route_resource lazy recursive";
module.exports = webpackAsyncContext;

/***/ }),

/***/ "./src/app/app-routing.module.ts":
/*!***************************************!*\
  !*** ./src/app/app-routing.module.ts ***!
  \***************************************/
/*! exports provided: AppRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppRoutingModule", function() { return AppRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");



var routes = [
    // { path: '', redirectTo: 'login', pathMatch: 'full' },
    { path: 'home', loadChildren: './pages/home/home.module#HomePageModule' },
    { path: 'login', loadChildren: './pages/login/login.module#LoginPageModule' },
    { path: 'events', loadChildren: './pages/events/events.module#EventsPageModule' },
    { path: 'event', loadChildren: './pages/event/event.module#EventPageModule' },
    { path: 'materials', loadChildren: './pages/materials/materials.module#MaterialsPageModule' },
    { path: 'event-materials', loadChildren: './pages/event-materials/event-materials.module#EventMaterialsPageModule' },
    { path: 'profile', loadChildren: './pages/profile/profile.module#ProfilePageModule' },
    { path: 'event-chat', loadChildren: './pages/event-chat/event-chat.module#EventChatPageModule' },
    { path: 'event-chat-general', loadChildren: './pages/event-chat-general/event-chat-general.module#EventChatGeneralPageModule' },
    { path: 'event-chats', loadChildren: './pages/event-chats/event-chats.module#EventChatsPageModule' }
];
var AppRoutingModule = /** @class */ (function () {
    function AppRoutingModule() {
    }
    AppRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [
                _angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forRoot(routes, { preloadingStrategy: _angular_router__WEBPACK_IMPORTED_MODULE_2__["PreloadAllModules"] })
            ],
            exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
        })
    ], AppRoutingModule);
    return AppRoutingModule;
}());



/***/ }),

/***/ "./src/app/app.component.html":
/*!************************************!*\
  !*** ./src/app/app.component.html ***!
  \************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-app>\n  <ion-router-outlet></ion-router-outlet>\n</ion-app>\n"

/***/ }),

/***/ "./src/app/app.component.ts":
/*!**********************************!*\
  !*** ./src/app/app.component.ts ***!
  \**********************************/
/*! exports provided: AppComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppComponent", function() { return AppComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _ionic_native_splash_screen_ngx__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic-native/splash-screen/ngx */ "./node_modules/@ionic-native/splash-screen/ngx/index.js");
/* harmony import */ var _ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic-native/status-bar/ngx */ "./node_modules/@ionic-native/status-bar/ngx/index.js");
/* harmony import */ var _ionic_storage__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/storage */ "./node_modules/@ionic/storage/fesm5/ionic-storage.js");






var AppComponent = /** @class */ (function () {
    function AppComponent(navController, platform, splashScreen, statusBar, storage, loadingController) {
        this.navController = navController;
        this.platform = platform;
        this.splashScreen = splashScreen;
        this.statusBar = statusBar;
        this.storage = storage;
        this.loadingController = loadingController;
        //this.storage.set('isLogin', true);
        //this.storage.clear();
        this.initializeApp();
    }
    AppComponent.prototype.initializeApp = function () {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var _this = this;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                this.platform.ready().then(function () { return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](_this, void 0, void 0, function () {
                    var _this = this;
                    return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                        switch (_a.label) {
                            case 0:
                                this.splashScreen.hide();
                                //this.headerColor.tint('#ffffff');
                                this.statusBar.styleDefault();
                                this.statusBar.backgroundColorByHexString('#ffffff');
                                return [4 /*yield*/, this.getLoginStatus().then(function (isLogin) {
                                        //alert(isLogin);
                                        if (isLogin) {
                                            //alert(1);
                                            _this.navController.navigateForward('/home');
                                        }
                                        else {
                                            //alert(1);
                                            _this.navController.navigateForward('/event-chat');
                                        }
                                    })];
                            case 1:
                                _a.sent();
                                return [2 /*return*/];
                        }
                    });
                }); });
                return [2 /*return*/];
            });
        });
    };
    AppComponent.prototype.getLoginStatus = function () {
        var _this = this;
        return new Promise(function (resolve, reject) {
            _this.storage.get('isLogin').then(function (isLogin) {
                resolve(isLogin);
            }, function (error) {
                reject(error);
            });
        });
    };
    AppComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-root',
            template: __webpack_require__(/*! ./app.component.html */ "./src/app/app.component.html")
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_2__["NavController"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["Platform"],
            _ionic_native_splash_screen_ngx__WEBPACK_IMPORTED_MODULE_3__["SplashScreen"],
            _ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_4__["StatusBar"],
            _ionic_storage__WEBPACK_IMPORTED_MODULE_5__["Storage"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["LoadingController"]])
    ], AppComponent);
    return AppComponent;
}());



/***/ }),

/***/ "./src/app/app.module.ts":
/*!*******************************!*\
  !*** ./src/app/app.module.ts ***!
  \*******************************/
/*! exports provided: AppModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppModule", function() { return AppModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/platform-browser */ "./node_modules/@angular/platform-browser/fesm5/platform-browser.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _ionic_native_splash_screen_ngx__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic-native/splash-screen/ngx */ "./node_modules/@ionic-native/splash-screen/ngx/index.js");
/* harmony import */ var _ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic-native/status-bar/ngx */ "./node_modules/@ionic-native/status-bar/ngx/index.js");
/* harmony import */ var _app_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./app.component */ "./src/app/app.component.ts");
/* harmony import */ var _app_routing_module__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./app-routing.module */ "./src/app/app-routing.module.ts");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
/* harmony import */ var _ionic_native_file_ngx__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @ionic-native/file/ngx */ "./node_modules/@ionic-native/file/ngx/index.js");
/* harmony import */ var _ionic_native_file_chooser_ngx__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @ionic-native/file-chooser/ngx */ "./node_modules/@ionic-native/file-chooser/ngx/index.js");
/* harmony import */ var _ionic_native_file_opener_ngx__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @ionic-native/file-opener/ngx */ "./node_modules/@ionic-native/file-opener/ngx/index.js");
/* harmony import */ var _ionic_native_file_path_ngx__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @ionic-native/file-path/ngx */ "./node_modules/@ionic-native/file-path/ngx/index.js");
/* harmony import */ var _ionic_native_file_transfer_ngx__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @ionic-native/file-transfer/ngx */ "./node_modules/@ionic-native/file-transfer/ngx/index.js");
/* harmony import */ var _ionic_native_google_plus_ngx__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! @ionic-native/google-plus/ngx */ "./node_modules/@ionic-native/google-plus/ngx/index.js");
/* harmony import */ var _ionic_native_facebook_ngx__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! @ionic-native/facebook/ngx */ "./node_modules/@ionic-native/facebook/ngx/index.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _ionic_storage__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! @ionic/storage */ "./node_modules/@ionic/storage/fesm5/ionic-storage.js");



















//import { SocketIoModule, SocketIoConfig } from 'ngx-socket-io';
//const config: SocketIoConfig = { url: 'http://localhost:3001', options: {} };
var AppModule = /** @class */ (function () {
    function AppModule() {
    }
    AppModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            declarations: [
                _app_component__WEBPACK_IMPORTED_MODULE_7__["AppComponent"]
            ],
            entryComponents: [],
            imports: [
                _angular_platform_browser__WEBPACK_IMPORTED_MODULE_2__["BrowserModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"].forRoot(),
                _ionic_storage__WEBPACK_IMPORTED_MODULE_18__["IonicStorageModule"].forRoot(),
                _app_routing_module__WEBPACK_IMPORTED_MODULE_8__["AppRoutingModule"],
                _angular_common_http__WEBPACK_IMPORTED_MODULE_9__["HttpClientModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_17__["FormsModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_17__["ReactiveFormsModule"],
            ],
            providers: [
                _ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_6__["StatusBar"],
                _ionic_native_splash_screen_ngx__WEBPACK_IMPORTED_MODULE_5__["SplashScreen"],
                _ionic_native_file_ngx__WEBPACK_IMPORTED_MODULE_10__["File"],
                _ionic_native_file_chooser_ngx__WEBPACK_IMPORTED_MODULE_11__["FileChooser"],
                _ionic_native_file_opener_ngx__WEBPACK_IMPORTED_MODULE_12__["FileOpener"],
                _ionic_native_file_path_ngx__WEBPACK_IMPORTED_MODULE_13__["FilePath"],
                _ionic_native_file_transfer_ngx__WEBPACK_IMPORTED_MODULE_14__["FileTransfer"],
                _ionic_native_google_plus_ngx__WEBPACK_IMPORTED_MODULE_15__["GooglePlus"],
                _ionic_native_facebook_ngx__WEBPACK_IMPORTED_MODULE_16__["Facebook"],
                { provide: _angular_router__WEBPACK_IMPORTED_MODULE_3__["RouteReuseStrategy"], useClass: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicRouteStrategy"] }
            ],
            bootstrap: [_app_component__WEBPACK_IMPORTED_MODULE_7__["AppComponent"]]
        })
    ], AppModule);
    return AppModule;
}());



/***/ }),

/***/ "./src/environments/environment.ts":
/*!*****************************************!*\
  !*** ./src/environments/environment.ts ***!
  \*****************************************/
/*! exports provided: environment */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "environment", function() { return environment; });
// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.
var environment = {
    production: false
};
/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.


/***/ }),

/***/ "./src/main.ts":
/*!*********************!*\
  !*** ./src/main.ts ***!
  \*********************/
/*! no exports provided */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/platform-browser-dynamic */ "./node_modules/@angular/platform-browser-dynamic/fesm5/platform-browser-dynamic.js");
/* harmony import */ var _app_app_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./app/app.module */ "./src/app/app.module.ts");
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./environments/environment */ "./src/environments/environment.ts");




if (_environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].production) {
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["enableProdMode"])();
}
Object(_angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_1__["platformBrowserDynamic"])().bootstrapModule(_app_app_module__WEBPACK_IMPORTED_MODULE_2__["AppModule"])
    .catch(function (err) { return console.log(err); });


/***/ }),

/***/ 0:
/*!***************************!*\
  !*** multi ./src/main.ts ***!
  \***************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(/*! D:\Workspace\ionic\tiripon-speaker-app\src\main.ts */"./src/main.ts");


/***/ })

},[[0,"runtime","vendor"]]]);
//# sourceMappingURL=main.js.map