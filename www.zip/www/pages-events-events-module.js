(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["pages-events-events-module"],{

/***/ "./src/app/pages/events/events.module.ts":
/*!***********************************************!*\
  !*** ./src/app/pages/events/events.module.ts ***!
  \***********************************************/
/*! exports provided: EventsPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "EventsPageModule", function() { return EventsPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _events_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./events.page */ "./src/app/pages/events/events.page.ts");







var routes = [
    {
        path: '',
        component: _events_page__WEBPACK_IMPORTED_MODULE_6__["EventsPage"]
    }
];
var EventsPageModule = /** @class */ (function () {
    function EventsPageModule() {
    }
    EventsPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterModule"].forChild(routes)
            ],
            declarations: [_events_page__WEBPACK_IMPORTED_MODULE_6__["EventsPage"]]
        })
    ], EventsPageModule);
    return EventsPageModule;
}());



/***/ }),

/***/ "./src/app/pages/events/events.page.html":
/*!***********************************************!*\
  !*** ./src/app/pages/events/events.page.html ***!
  \***********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n<ion-header>\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <ion-back-button defaultHref=\"/home\"></ion-back-button> \n    </ion-buttons>\n    <ion-title style=\"font-weight: 400;\">Events</ion-title>\n    <!-- <ion-buttons slot=\"end\">\n      <ion-button>\n        <ion-icon name=\"search\"></ion-icon>\n      </ion-button>\n      <ion-button>\n        <ion-icon name=\"more\"></ion-icon>\n      </ion-button>\n    </ion-buttons> -->\n    \n  </ion-toolbar>\n</ion-header>\n\n<ion-content>  \n  <!--<ion-item lines=\"none\">\n    <ion-searchbar placeholder=\"Seach all events...\"></ion-searchbar>\n    <ion-button color=\"light\" shape=\"round\">\n      <ion-icon name=\"options\"></ion-icon>\n    </ion-button>     \n  </ion-item>-->\n\n \n  \n  <ion-list *ngIf=\"events\" color=\"light\"> \n    <ion-item class=\"item\" *ngFor=\"let event of events\" (click)=\"navigateToEventPage(event)\" lines=\"none\" button>\n      <ion-ripple-effect type=\"bounded\"></ion-ripple-effect>\n      <ion-thumbnail slot=\"start\">\n        <ion-img src=\"{{ baseUrl + event.event_image_path }}\"></ion-img>\n      </ion-thumbnail>\n      <ion-label>\n        <p style=\"color: black; font-size: 16px; font-weight: 350;\"> \n          {{ event.event_title }}\n        </p>\n        <p style=\"font-size: 12px; font-weight: 300;\"> \n          {{ event.province }}, {{ event.country }} \n        </p> \n        <p style=\"font-size: 12px; font-weight: 300;\">  \n          {{ event.start | date : \"mediumDate\" }} \n        </p> \n      </ion-label> \n    </ion-item>    \n  </ion-list>\n\n  <ion-list *ngIf=\"!events\" color=\"light\"> \n    <ion-item class=\"item\" lines=\"none\" *ngFor=\"let skeletonItem of skeletonItems\">\n      <ion-thumbnail slot=\"start\">\n        <ion-skeleton-text animated style=\"width: 100%\"></ion-skeleton-text>\n      </ion-thumbnail>\n      <ion-label>\n        <p style=\"color: black; font-size: 16px; font-weight: 350;\"> \n          <ion-skeleton-text animated style=\"width: 100%\"></ion-skeleton-text>\n        </p>\n        <p style=\"font-size: 12px; font-weight: 300;\"> \n          <ion-skeleton-text animated style=\"width: 75%\"></ion-skeleton-text>\n        </p> \n        <p style=\"font-size: 12px; font-weight: 300;\">  \n          <ion-skeleton-text animated style=\"width: 50%\"></ion-skeleton-text>\n        </p> \n      </ion-label> \n    </ion-item>    \n  </ion-list>\n        \n</ion-content>\n"

/***/ }),

/***/ "./src/app/pages/events/events.page.scss":
/*!***********************************************!*\
  !*** ./src/app/pages/events/events.page.scss ***!
  \***********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".item ion-thumbnail {\n  min-width: 120px;\n  min-height: 70px;\n  --border-radius: 5%; }\n  .item ion-thumbnail img {\n    min-width: 120px;\n    min-height: 70px; }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcGFnZXMvZXZlbnRzL0Q6XFxXb3Jrc3BhY2VcXGlvbmljXFx0aXJpcG9uLXNwZWFrZXItYXBwL3NyY1xcYXBwXFxwYWdlc1xcZXZlbnRzXFxldmVudHMucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0UsZ0JBQWdCO0VBQ2hCLGdCQUFnQjtFQUtoQixtQkFBZ0IsRUFBQTtFQVBsQjtJQUlJLGdCQUFnQjtJQUNoQixnQkFBZ0IsRUFBQSIsImZpbGUiOiJzcmMvYXBwL3BhZ2VzL2V2ZW50cy9ldmVudHMucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLml0ZW0gaW9uLXRodW1ibmFpbCB7XHJcbiAgbWluLXdpZHRoOiAxMjBweDsgICAgXHJcbiAgbWluLWhlaWdodDogNzBweDtcclxuICBpbWcge1xyXG4gICAgbWluLXdpZHRoOiAxMjBweDsgICAgXHJcbiAgICBtaW4taGVpZ2h0OiA3MHB4OyBcclxuICB9XHJcbiAgLS1ib3JkZXItcmFkaXVzOiA1JTtcclxufSJdfQ== */"

/***/ }),

/***/ "./src/app/pages/events/events.page.ts":
/*!*********************************************!*\
  !*** ./src/app/pages/events/events.page.ts ***!
  \*********************************************/
/*! exports provided: EventsPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "EventsPage", function() { return EventsPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _services_api_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../services/api.service */ "./src/app/services/api.service.ts");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");




var EventsPage = /** @class */ (function () {
    function EventsPage(apiService, alertController, loadingController, navController) {
        this.apiService = apiService;
        this.alertController = alertController;
        this.loadingController = loadingController;
        this.navController = navController;
        this.events = undefined;
        this.baseUrl = 'https://www.tiripon.net/assets/event_image/landing/';
        this.skeletonItems = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10];
    }
    EventsPage.prototype.ngOnInit = function () {
        this.getEvents();
    };
    EventsPage.prototype.getEvents = function () {
        var _this = this;
        //this.presentLoading('').then(() => {
        this.apiService.getEvents().then(function (events) {
            if (_this.hasEvents(events)) {
                //alert(1);
                _this.events = events;
                _this.dismissLoading();
                //alert(JSON.stringify(this.events));
            }
            else {
                //alert(2);
                _this.events = [];
                _this.dismissLoading();
            }
        });
        //}); 
    };
    EventsPage.prototype.hasEvents = function (events) {
        var numberOfEvents = events.length;
        if (numberOfEvents >= 1) {
            return true;
        }
        else {
            return false;
        }
    };
    EventsPage.prototype.presentLoading = function (message) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var options, _a;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_b) {
                switch (_b.label) {
                    case 0:
                        options = {
                            message: message
                        };
                        _a = this;
                        return [4 /*yield*/, this.loadingController.create(options)];
                    case 1:
                        _a.loading = _b.sent();
                        return [4 /*yield*/, this.loading.present()];
                    case 2:
                        _b.sent();
                        return [2 /*return*/];
                }
            });
        });
    };
    EventsPage.prototype.dismissLoading = function () {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.loading.dismiss()];
                    case 1:
                        _a.sent();
                        return [2 /*return*/];
                }
            });
        });
    };
    EventsPage.prototype.navigateToEventPage = function (event) {
        var parameters = {
            queryParams: event
        };
        //alert(JSON.stringify(event));
        this.navController.navigateForward(['/event'], parameters);
    };
    EventsPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-events',
            template: __webpack_require__(/*! ./events.page.html */ "./src/app/pages/events/events.page.html"),
            styles: [__webpack_require__(/*! ./events.page.scss */ "./src/app/pages/events/events.page.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_services_api_service__WEBPACK_IMPORTED_MODULE_2__["ApiService"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["AlertController"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["LoadingController"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["NavController"]])
    ], EventsPage);
    return EventsPage;
}());



/***/ })

}]);
//# sourceMappingURL=pages-events-events-module.js.map