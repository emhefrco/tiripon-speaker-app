(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["pages-event-materials-event-materials-module"],{

/***/ "./src/app/pages/event-materials/event-materials.module.ts":
/*!*****************************************************************!*\
  !*** ./src/app/pages/event-materials/event-materials.module.ts ***!
  \*****************************************************************/
/*! exports provided: EventMaterialsPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "EventMaterialsPageModule", function() { return EventMaterialsPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _event_materials_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./event-materials.page */ "./src/app/pages/event-materials/event-materials.page.ts");







var routes = [
    {
        path: '',
        component: _event_materials_page__WEBPACK_IMPORTED_MODULE_6__["EventMaterialsPage"]
    }
];
var EventMaterialsPageModule = /** @class */ (function () {
    function EventMaterialsPageModule() {
    }
    EventMaterialsPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterModule"].forChild(routes)
            ],
            declarations: [_event_materials_page__WEBPACK_IMPORTED_MODULE_6__["EventMaterialsPage"]]
        })
    ], EventMaterialsPageModule);
    return EventMaterialsPageModule;
}());



/***/ }),

/***/ "./src/app/pages/event-materials/event-materials.page.html":
/*!*****************************************************************!*\
  !*** ./src/app/pages/event-materials/event-materials.page.html ***!
  \*****************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header>\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <ion-back-button defaultHref=\"/materials\"></ion-back-button> \n    </ion-buttons>\n    <ion-title style=\"font-weight: 400;\">Event materials</ion-title> \n  </ion-toolbar>\n</ion-header>\n\n<ion-content>  \n  <ion-item lines=\"full\" *ngIf=\"!doesEventHaveMaterials(eventMaterials)\">\n    <ion-label>\n      <p style=\"font-size: 16px; color: black; font-weight: 350;\">\n      No materials found\n      </p> \n    </ion-label>\n    \n  </ion-item>\n  <ion-list *ngIf=\"eventMaterials\">\n    <ion-item class=\"item\" *ngFor=\"let material of eventMaterials\" lines=\"none\" button>\n      <ion-ripple-effect type=\"bounded\"></ion-ripple-effect>\n      <ion-thumbnail *ngIf=\"isImage(material)\" slot=\"start\">\n        <ion-img src=\"{{ baseUrl + material.filename }}\"></ion-img>\n      </ion-thumbnail>   \n      <ion-thumbnail *ngIf=\"isPDF(material)\" slot=\"start\">\n        <ion-img src=\"assets/images/pdf.png\"></ion-img>\n      </ion-thumbnail>  \n      <ion-thumbnail *ngIf=\"isMP4(material)\" slot=\"start\">\n        <ion-img src=\"assets/images/mp4.png\"></ion-img>\n      </ion-thumbnail> \n      <ion-label>\n        <p style=\"font-size: 16px; color: black; font-weight: 350;\">{{ material.title }}</p>\n        <p style=\"font-size: 12px; font-weight: 300;\">{{ formatSize(material.size) }}</p>\n      </ion-label>   \n      <!-- <ion-button slot=\"end\" no-margin>\n        <ion-icon color=\"medium\" name=\"more\" size=\"small\" (click)=\"click()\"></ion-icon>  \n      </ion-button> -->\n    </ion-item>  \n  </ion-list> \n\n  <ion-list *ngIf=\"!eventMaterials\">\n    <ion-item class=\"item\" lines=\"none\" *ngFor=\"let skeletonItem of skeletonItems\">\n      \n      <ion-thumbnail slot=\"start\">\n        <ion-skeleton-text animated style=\"width: 100%\"></ion-skeleton-text>\n      </ion-thumbnail>   \n      <ion-label>\n        <p style=\"font-size: 16px; color: black; font-weight: 350;\">\n          <ion-skeleton-text animated style=\"width: 82.5%\"></ion-skeleton-text>\n        </p>\n        <p style=\"font-size: 12px; font-weight: 300;\">\n          <ion-skeleton-text animated style=\"width: 15%\"></ion-skeleton-text>\n        </p>\n      </ion-label>   \n    </ion-item>  \n  </ion-list> \n\n  \n  <ion-fab vertical=\"bottom\" horizontal=\"end\" slot=\"fixed\" margin-end margin-bottom>\n    <ion-fab-button color=\"light\" (click)=\"onChooseFile()\"> \n      <ion-icon color=\"primary\" name=\"add\" large></ion-icon>\n    </ion-fab-button>\n    <!-- <ion-fab-button color=\"medium\" (click)=\"onDownloadFile()\">\n      <ion-icon name=\"star\"></ion-icon>\n    </ion-fab-button> -->\n  </ion-fab> \n\n</ion-content>\n\n"

/***/ }),

/***/ "./src/app/pages/event-materials/event-materials.page.scss":
/*!*****************************************************************!*\
  !*** ./src/app/pages/event-materials/event-materials.page.scss ***!
  \*****************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3BhZ2VzL2V2ZW50LW1hdGVyaWFscy9ldmVudC1tYXRlcmlhbHMucGFnZS5zY3NzIn0= */"

/***/ }),

/***/ "./src/app/pages/event-materials/event-materials.page.ts":
/*!***************************************************************!*\
  !*** ./src/app/pages/event-materials/event-materials.page.ts ***!
  \***************************************************************/
/*! exports provided: EventMaterialsPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "EventMaterialsPage", function() { return EventMaterialsPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _services_api_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../services/api.service */ "./src/app/services/api.service.ts");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _ionic_native_file_ngx__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic-native/file/ngx */ "./node_modules/@ionic-native/file/ngx/index.js");
/* harmony import */ var _ionic_native_file_chooser_ngx__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic-native/file-chooser/ngx */ "./node_modules/@ionic-native/file-chooser/ngx/index.js");
/* harmony import */ var _ionic_native_file_opener_ngx__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic-native/file-opener/ngx */ "./node_modules/@ionic-native/file-opener/ngx/index.js");
/* harmony import */ var _ionic_native_file_path_ngx__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @ionic-native/file-path/ngx */ "./node_modules/@ionic-native/file-path/ngx/index.js");
/* harmony import */ var _ionic_native_file_transfer_ngx__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @ionic-native/file-transfer/ngx */ "./node_modules/@ionic-native/file-transfer/ngx/index.js");










var EventMaterialsPage = /** @class */ (function () {
    function EventMaterialsPage(route, apiService, alertController, loadingController, navController, file, fileChooser, filePath, fileOpener, fileTransfer) {
        this.route = route;
        this.apiService = apiService;
        this.alertController = alertController;
        this.loadingController = loadingController;
        this.navController = navController;
        this.file = file;
        this.fileChooser = fileChooser;
        this.filePath = filePath;
        this.fileOpener = fileOpener;
        this.fileTransfer = fileTransfer;
        this.baseUrl = 'https://www.tiripon.net/assets/dashboard/images/speaker/material/images/';
        this.skeletonItems = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10];
    }
    EventMaterialsPage.prototype.click = function () {
        alert(1);
    };
    EventMaterialsPage.prototype.ngOnInit = function () {
        var _this = this;
        this.getEvent().then(function (event) {
            _this.event = event;
            _this.getEventMaterials(event);
        });
    };
    EventMaterialsPage.prototype.getEvent = function () {
        var _this = this;
        var promise = new Promise(function (resolve, reject) {
            _this.route.queryParams.subscribe(function (event) {
                resolve(event);
            }, function (error) {
                reject(error);
            });
        }).catch(function () {
            alert('Error in getting event!');
        });
        return promise;
    };
    EventMaterialsPage.prototype.getEventMaterials = function (event) {
        var _this = this;
        this.apiService.getEventMaterials(event).then(function (eventMaterials) {
            //alert(JSON.stringify(eventMaterials));
            if (_this.doesEventHaveMaterials(eventMaterials)) {
                _this.eventMaterials = eventMaterials;
            }
            else {
                _this.eventMaterials = [];
            }
        });
    };
    EventMaterialsPage.prototype.doesEventHaveMaterials = function (eventMaterials) {
        var numberOfMaterials = eventMaterials.length;
        if (numberOfMaterials > 0) {
            return true;
        }
        else {
            return false;
        }
    };
    EventMaterialsPage.prototype.presentLoading = function (message) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var options, _a;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_b) {
                switch (_b.label) {
                    case 0:
                        options = {
                            message: message
                        };
                        _a = this;
                        return [4 /*yield*/, this.loadingController.create(options)];
                    case 1:
                        _a.loading = _b.sent();
                        return [4 /*yield*/, this.loading.present()];
                    case 2:
                        _b.sent();
                        return [2 /*return*/];
                }
            });
        });
    };
    EventMaterialsPage.prototype.dismissLoading = function () {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.loading.dismiss()];
                    case 1:
                        _a.sent();
                        return [2 /*return*/];
                }
            });
        });
    };
    EventMaterialsPage.prototype.onChooseFile = function () {
        var _this = this;
        var imageUrl = 'https://www.tiripon.net/assets/dashboard/images/speaker/material/documents/tiripon_f4cbfe1e18f291371fc0a9bd9a4f6924.jpg';
        var url = 'https://tiripon.net/Android_Api_Speaker/upload_material';
        var fileReader = new FileReader();
        this.fileChooser.open().then(function (uri) {
            _this.presentLoading('Uploading file.').then(function () {
                _this.filePath.resolveNativePath(uri).then(function (resolvedNativePath) {
                    _this.file.resolveLocalFilesystemUrl(resolvedNativePath).then(function () {
                        _this.getFileInformation(resolvedNativePath).then(function (file) {
                            //alert(JSON.stringify(event));
                            //alert(JSON.stringify(file)); return;
                            _this.apiService.uploadFile(_this.event, file).then(function (uploadedFile) {
                                //alert(JSON.stringify(uploadedFile));
                                _this.uploadedFile = uploadedFile;
                                _this.dismissLoading();
                                //alert('Done!');
                                //alert(JSON.stringify(uploadedFile));
                                _this.presentAlert('File has been uploaded.');
                            });
                        });
                    });
                });
            });
        });
    };
    EventMaterialsPage.prototype.getFileInformation = function (filePath) {
        var _this = this;
        return new Promise(function (resolve, reject) {
            _this.file.resolveLocalFilesystemUrl(filePath).then(function (entry) {
                entry.file(function (file) {
                    resolve(file);
                });
            }, function (error) {
                reject(error);
            });
        });
    };
    EventMaterialsPage.prototype.addNewFile = function (file) {
        //alert(JSON.stringify(file));
        this.eventMaterials.unshift({
            title: file.client_name,
            extension: file.extension,
            size: file.size,
            filename: file.file_name
        });
    };
    EventMaterialsPage.prototype.presentAlert = function (message) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var alert;
            var _this = this;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.alertController.create({
                            message: message,
                            buttons: [
                                {
                                    text: 'Ok',
                                    handler: function () {
                                        _this.addNewFile(_this.uploadedFile);
                                    }
                                }
                            ]
                        })];
                    case 1:
                        alert = _a.sent();
                        return [4 /*yield*/, alert.present()];
                    case 2:
                        _a.sent();
                        return [2 /*return*/];
                }
            });
        });
    };
    EventMaterialsPage.prototype.isImage = function (material) {
        if (material.extension === 'jpg' ||
            material.extension === 'jpeg' ||
            material.extension === 'png') {
            return true;
        }
    };
    EventMaterialsPage.prototype.isPDF = function (material) {
        if (material.extension === 'pdf') {
            return true;
        }
    };
    EventMaterialsPage.prototype.isMP4 = function (material) {
        if (material.extension === 'mp4') {
            return true;
        }
    };
    EventMaterialsPage.prototype.isOtherFile = function (material) {
        if (!this.isImage(material) &&
            !this.isPDF(material) &&
            !this.isMP4(material)) {
            return true;
        }
    };
    EventMaterialsPage.prototype.formatSize = function (bytes) {
        //alert(bytes);
        var sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB'];
        if (bytes == 0) {
            return '0 Byte';
        }
        else {
            var i = Math.floor(Math.log(bytes) / Math.log(1024));
            return Math.round(bytes / Math.pow(1024, i)) + ' ' + sizes[i];
        }
    };
    EventMaterialsPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-event-materials',
            template: __webpack_require__(/*! ./event-materials.page.html */ "./src/app/pages/event-materials/event-materials.page.html"),
            styles: [__webpack_require__(/*! ./event-materials.page.scss */ "./src/app/pages/event-materials/event-materials.page.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"],
            _services_api_service__WEBPACK_IMPORTED_MODULE_3__["ApiService"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["AlertController"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["LoadingController"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["NavController"],
            _ionic_native_file_ngx__WEBPACK_IMPORTED_MODULE_5__["File"],
            _ionic_native_file_chooser_ngx__WEBPACK_IMPORTED_MODULE_6__["FileChooser"],
            _ionic_native_file_path_ngx__WEBPACK_IMPORTED_MODULE_8__["FilePath"],
            _ionic_native_file_opener_ngx__WEBPACK_IMPORTED_MODULE_7__["FileOpener"],
            _ionic_native_file_transfer_ngx__WEBPACK_IMPORTED_MODULE_9__["FileTransfer"]])
    ], EventMaterialsPage);
    return EventMaterialsPage;
}());



/***/ })

}]);
//# sourceMappingURL=pages-event-materials-event-materials-module.js.map